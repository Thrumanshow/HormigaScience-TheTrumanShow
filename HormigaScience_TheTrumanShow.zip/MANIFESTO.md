# MANIFIESTO HormigaScience: The Truman Show

En un mundo donde la automatización, la inteligencia artificial y las plataformas centralizadas moldean cada aspecto de nuestras decisiones, **HormigaScience** surge como un proyecto de resistencia creativa, documentación activa y conciencia digital.

## ¿Por qué The Truman Show?

Porque muchos vivimos dentro de sistemas que observan, influyen y reconfiguran nuestras decisiones sin que lo notemos. **HormigaScience** se posiciona como una bitácora pública y transparente desde "dentro del show", pero con el objetivo de salir de él, o al menos entenderlo y adaptarlo a nuestras reglas.

## Principios rectores

- **Conciencia digital**: saber qué compartimos, dónde lo compartimos y con quién.
- **Autonomía tecnológica**: herramientas de código abierto y autoalojamiento.
- **Educación libre**: conocimiento en español, accesible, sin tecnicismos innecesarios.
- **Reciprocidad**: respetar a la comunidad, exigir respeto por los datos, construir desde la colaboración.

## Nuestros espacios

- Documentamos en GitHub.
- Extendemos contexto en Wikipedia.
- Difundimos en redes y newsletters.
- Creamos puentes, no muros, entre la automatización y la humanidad.

## Advertencia amistosa

Este repositorio contiene configuraciones diseñadas para resistir desconfiguraciones forzadas de plataformas externas. No es paranoia, es previsión. No es desconfianza, es independencia responsable.

---

**“Las HormigasAIS encuentran sabiduría en silencio, su corazón enraizado en la tierra y su mente flotando entre las estrellas.”**

*Creado por Cristhiam Quiñonez — HormigasAIS | IA + Comunicación + Datos*
